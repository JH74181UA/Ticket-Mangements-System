export const colors = {
    bg: '#0a0e1a',
    bgCard: '#0f1628',
    primary: '#6c63ff',
    primaryLight: 'rgba(108,99,255,0.15)',
    accent: '#a78bfa',
    success: '#22c55e',
    warning: '#f59e0b',
    danger: '#ef4444',
    info: '#3b82f6',
    text: '#e2e8f0',
    textDim: '#64748b',
    border: 'rgba(255,255,255,0.08)',
    glass: 'rgba(255,255,255,0.04)',
    statusPending: '#f59e0b',
    statusAssigned: '#3b82f6',
    statusInProgress: '#a78bfa',
    statusOnHold: '#64748b',
    statusCompleted: '#22c55e',
};

export const statusColor = (status) => {
    switch (status) {
        case 'Pending': return colors.statusPending;
        case 'Assigned': return colors.statusAssigned;
        case 'In-Progress': return colors.statusInProgress;
        case 'On-Hold': return colors.statusOnHold;
        case 'Completed': return colors.statusCompleted;
        default: return colors.textDim;
    }
};
