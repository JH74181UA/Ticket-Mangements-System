import React, { useState, useEffect, useCallback } from 'react';
import {
    View, Text, FlatList, TouchableOpacity,
    StyleSheet, ActivityIndicator, RefreshControl
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import api from '../api';
import { colors } from '../theme';

export default function NotificationsScreen() {
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const fetchData = async () => {
        try {
            const res = await api.get('/notifications');
            setNotifications(res.data);
        } catch (err) { console.warn('Notifications fetch error:', err.response?.data?.message || err.message); }
        finally { setLoading(false); setRefreshing(false); }
    };

    const markRead = async (id) => {
        try {
            await api.put(`/notifications/${id}/read`);
            setNotifications(prev => prev.map(n => n._id === id ? { ...n, read: true } : n));
        } catch { }
    };

    const markAllRead = async () => {
        try {
            await api.put('/notifications/mark-all-read');
            setNotifications(prev => prev.map(n => ({ ...n, read: true })));
        } catch { }
    };

    useFocusEffect(
        useCallback(() => {
            fetchData();
        }, [])
    );

    const unread = notifications.filter(n => !n.read).length;

    const renderItem = ({ item }) => (
        <TouchableOpacity
            style={[s.card, !item.read && s.cardUnread]}
            onPress={() => !item.read && markRead(item._id)}
        >
            <View style={[s.dot, { backgroundColor: item.read ? colors.textDim : colors.primary }]} />
            <View style={{ flex: 1 }}>
                <Text style={s.message}>{item.message}</Text>
                <Text style={s.time}>{new Date(item.createdAt).toLocaleString()}</Text>
            </View>
            {!item.read && (
                <View style={s.unreadBadge}>
                    <Text style={s.unreadText}>New</Text>
                </View>
            )}
        </TouchableOpacity>
    );

    return (
        <View style={s.container}>
            {/* Header */}
            <View style={s.header}>
                <View>
                    <Text style={s.title}>Notifications</Text>
                    {unread > 0 && <Text style={s.sub}>{unread} unread</Text>}
                </View>
                {unread > 0 && (
                    <TouchableOpacity style={s.markAllBtn} onPress={markAllRead}>
                        <Text style={s.markAllText}>Mark all read</Text>
                    </TouchableOpacity>
                )}
            </View>

            {loading ? (
                <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 60 }} />
            ) : (
                <FlatList
                    data={notifications}
                    keyExtractor={i => i._id}
                    renderItem={renderItem}
                    contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
                    refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor={colors.primary} />}
                    ListEmptyComponent={
                        <View style={s.emptyWrap}>
                            <Ionicons name="notifications-off-outline" size={48} color={colors.textDim} />
                            <Text style={s.empty}>No notifications yet.</Text>
                        </View>
                    }
                />
            )}
        </View>
    );
}

const s = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.bg },
    header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, paddingBottom: 12 },
    title: { fontSize: 24, fontWeight: '800', color: colors.text },
    sub: { fontSize: 13, color: colors.primary, marginTop: 2 },
    markAllBtn: { backgroundColor: colors.primaryLight, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
    markAllText: { color: colors.primary, fontWeight: '700', fontSize: 13 },
    card: { flexDirection: 'row', alignItems: 'flex-start', gap: 14, backgroundColor: colors.bgCard, borderRadius: 16, padding: 16, marginBottom: 10, borderWidth: 1, borderColor: colors.border },
    cardUnread: { borderColor: colors.primary + '40', backgroundColor: colors.primaryLight },
    dot: { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
    message: { fontSize: 14, color: colors.text, lineHeight: 20 },
    time: { fontSize: 12, color: colors.textDim, marginTop: 4 },
    unreadBadge: { backgroundColor: colors.primary, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2 },
    unreadText: { color: '#fff', fontSize: 10, fontWeight: '700' },
    emptyWrap: { alignItems: 'center', marginTop: 80, gap: 12 },
    empty: { color: colors.textDim, fontSize: 15 },
});
