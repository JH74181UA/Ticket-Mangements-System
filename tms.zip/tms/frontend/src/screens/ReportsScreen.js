import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import api from '../api';
import { colors, statusColor } from '../theme';

const STATUSES = ['Pending', 'Assigned', 'In-Progress', 'On-Hold', 'Completed'];

export default function ReportsScreen() {
    const [user, setUser] = useState({ role: 'User' });
    const [stats, setStats] = useState({});
    const [complaints, setComplaints] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const fetchData = async () => {
        try {
            const userStr = await AsyncStorage.getItem('user');
            const u = userStr ? JSON.parse(userStr) : user;
            setUser(u);
            const [statsRes, compRes] = await Promise.all([
                api.get('/complaints/stats').catch(e => { console.warn('Stats error:', e.message); return { data: {} }; }),
                api.get(u.role === 'SuperAdmin' ? '/complaints/all' : '/complaints/my-complaints').catch(e => { console.warn('Reports complaints error:', e.message); return { data: [] }; }),
            ]);
            if (statsRes?.data) setStats(statsRes.data);
            if (Array.isArray(compRes?.data)) setComplaints(compRes.data);
        } catch (err) {
            console.error('Reports fetchData error:', err);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            fetchData();
        }, [])
    );

    const total = complaints.length || 1;
    const typeGroups = complaints.reduce((acc, c) => {
        acc[c.complaintType] = (acc[c.complaintType] || 0) + 1;
        return acc;
    }, {});

    if (loading) return <View style={[s.container, { justifyContent: 'center', alignItems: 'center' }]}><ActivityIndicator size="large" color={colors.primary} /></View>;

    return (
        <ScrollView
            style={s.container}
            contentContainerStyle={s.content}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor={colors.primary} />}
        >
            <Text style={s.title}>Reports & Analytics</Text>

            {/* Status Breakdown */}
            <View style={s.card}>
                <Text style={s.cardTitle}>Status Breakdown</Text>
                {STATUSES.map(st => {
                    const count = stats[st] || 0;
                    const pct = Math.round((count / total) * 100);
                    return (
                        <View key={st} style={{ marginBottom: 16 }}>
                            <View style={s.barHeader}>
                                <Text style={[s.barLabel, { color: statusColor(st) }]}>{st}</Text>
                                <Text style={s.barCount}>{count} ({pct}%)</Text>
                            </View>
                            <View style={s.barBg}>
                                <View style={[s.barFill, { width: `${pct}%`, backgroundColor: statusColor(st) }]} />
                            </View>
                        </View>
                    );
                })}
            </View>

            {/* Summary Cards */}
            <View style={s.grid}>
                {[
                    { label: 'Total', value: stats.Total || 0, icon: 'ticket-outline', color: colors.primary },
                    { label: 'Pending', value: stats.Pending || 0, icon: 'time-outline', color: colors.warning },
                    { label: 'Completed', value: stats.Completed || 0, icon: 'checkmark-circle-outline', color: colors.success },
                    { label: 'In Progress', value: (stats.Assigned || 0) + (stats['In-Progress'] || 0), icon: 'settings-outline', color: colors.info },
                ].map(item => (
                    <View key={item.label} style={[s.statCard, { borderColor: item.color + '30' }]}>
                        <Ionicons name={item.icon} size={24} color={item.color} />
                        <Text style={[s.statValue, { color: item.color }]}>{item.value}</Text>
                        <Text style={s.statLabel}>{item.label}</Text>
                    </View>
                ))}
            </View>

            {/* By Category */}
            <View style={s.card}>
                <Text style={s.cardTitle}>By Category</Text>
                {Object.entries(typeGroups).sort((a, b) => b[1] - a[1]).map(([type, count]) => (
                    <View key={type} style={s.catRow}>
                        <View style={s.catDot} />
                        <Text style={s.catLabel}>{type}</Text>
                        <View style={s.catBarWrap}>
                            <View style={[s.catBar, { width: `${Math.round((count / total) * 100)}%` }]} />
                        </View>
                        <Text style={s.catCount}>{count}</Text>
                    </View>
                ))}
            </View>
        </ScrollView>
    );
}

const s = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.bg },
    content: { padding: 20, paddingBottom: 40 },
    title: { fontSize: 24, fontWeight: '800', color: colors.text, marginBottom: 24 },
    card: { backgroundColor: colors.bgCard, borderRadius: 20, padding: 20, marginBottom: 20, borderWidth: 1, borderColor: colors.border },
    cardTitle: { fontSize: 16, fontWeight: '700', color: colors.text, marginBottom: 20 },
    barHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
    barLabel: { fontSize: 13, fontWeight: '700' },
    barCount: { color: colors.textDim, fontSize: 12 },
    barBg: { height: 8, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 4 },
    barFill: { height: 8, borderRadius: 4 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
    statCard: { flex: 1, minWidth: '45%', backgroundColor: colors.bgCard, borderRadius: 18, padding: 18, alignItems: 'center', gap: 8, borderWidth: 1 },
    statValue: { fontSize: 28, fontWeight: '800' },
    statLabel: { fontSize: 12, color: colors.textDim, fontWeight: '600' },
    catRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
    catDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary },
    catLabel: { color: colors.text, fontSize: 13, width: 110 },
    catBarWrap: { flex: 1, height: 6, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 3 },
    catBar: { height: 6, backgroundColor: colors.primary, borderRadius: 3 },
    catCount: { color: colors.textDim, fontSize: 13, width: 24, textAlign: 'right' },
});
