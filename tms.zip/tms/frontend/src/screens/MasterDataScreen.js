import React, { useState, useEffect } from 'react';
import {
    View, Text, FlatList, TouchableOpacity, TextInput,
    StyleSheet, Alert, Modal, ScrollView, ActivityIndicator
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import api from '../api';
import { colors } from '../theme';

/**
 * Generic master data CRUD screen.
 * Props:
 *   endpoint   - e.g. '/master/departments'
 *   title      - Screen title
 *   fields     - Array of { key, label, placeholder, keyboardType? }
 */
export default function MasterDataScreen({ endpoint, title, fields }) {
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [modalVisible, setModalVisible] = useState(false);
    const [editItem, setEditItem] = useState(null);
    const [form, setForm] = useState({});

    const fetchData = async () => {
        try {
            const res = await api.get(endpoint);
            setItems(res.data);
        } catch (err) {
            console.error(`Failed to load ${endpoint}:`, err.response?.data || err.message);
            Alert.alert('Error', err.response?.data?.message || 'Failed to load data');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchData(); }, []);

    const openCreate = () => {
        setEditItem(null);
        const empty = {};
        fields.forEach(f => empty[f.key] = '');
        setForm(empty);
        setModalVisible(true);
    };

    const openEdit = (item) => {
        setEditItem(item);
        const f = {};
        fields.forEach(field => {
            const val = item[field.key];
            f[field.key] = (typeof val === 'object' && val !== null ? (val.name || val._id) : val) || '';
        });
        setForm(f);
        setModalVisible(true);
    };

    const handleSave = async () => {
        try {
            if (editItem) {
                await api.put(`${endpoint}/${editItem._id}`, form);
            } else {
                await api.post(endpoint, form);
            }
            setModalVisible(false);
            fetchData();
        } catch (err) {
            console.error('Save error:', err.response?.data || err.message);
            Alert.alert('Error', err.response?.data?.message || 'Save failed');
        }
    };

    const handleDelete = (id) => {
        Alert.alert('Delete', 'Are you sure?', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Delete', style: 'destructive', onPress: async () => {
                    try {
                        await api.delete(`${endpoint}/${id}`);
                        fetchData();
                    } catch { Alert.alert('Error', 'Delete failed'); }
                }
            }
        ]);
    };

    const renderItem = ({ item }) => (
        <View style={s.card}>
            <View style={{ flex: 1 }}>
                {fields.map(f => {
                    const rawVal = item[f.key];
                    const val = typeof rawVal === 'object' && rawVal !== null
                        ? (rawVal.name || rawVal.roomNumber || rawVal._id || '—')
                        : (rawVal || '—');
                    return (
                        <Text key={f.key} style={f.key === fields[0].key ? s.primary : s.secondary}>
                            {f.key === fields[0].key ? val : `${f.label}: ${val}`}
                        </Text>
                    );
                })}
            </View>
            <TouchableOpacity style={s.iconBtn} onPress={() => openEdit(item)}>
                <Ionicons name="pencil-outline" size={18} color={colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={s.iconBtn} onPress={() => handleDelete(item._id)}>
                <Ionicons name="trash-outline" size={18} color={colors.danger} />
            </TouchableOpacity>
        </View>
    );

    return (
        <View style={s.container}>
            <View style={s.topBar}>
                <Text style={s.title}>{title}</Text>
                <TouchableOpacity style={s.addBtn} onPress={openCreate}>
                    <Ionicons name="add" size={20} color="#fff" />
                    <Text style={s.addText}>Add</Text>
                </TouchableOpacity>
            </View>

            {loading
                ? <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 60 }} />
                : <FlatList
                    data={items}
                    keyExtractor={i => i._id}
                    renderItem={renderItem}
                    contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
                    ListEmptyComponent={<Text style={s.empty}>No records yet. Tap Add to create one.</Text>}
                />
            }

            <Modal visible={modalVisible} animationType="slide" transparent>
                <View style={s.overlay}>
                    <View style={s.modal}>
                        <View style={s.modalHeader}>
                            <Text style={s.modalTitle}>{editItem ? 'Edit' : 'Add'} {title.replace(/s$/, '')}</Text>
                            <TouchableOpacity onPress={() => setModalVisible(false)}>
                                <Ionicons name="close" size={24} color={colors.text} />
                            </TouchableOpacity>
                        </View>
                        <ScrollView>
                            {fields.map(f => (
                                <View key={f.key} style={{ marginBottom: 16 }}>
                                    <Text style={s.label}>{f.label}</Text>
                                    <TextInput
                                        style={s.input}
                                        placeholder={f.placeholder}
                                        placeholderTextColor={colors.textDim}
                                        value={form[f.key] || ''}
                                        onChangeText={v => setForm(prev => ({ ...prev, [f.key]: v }))}
                                        keyboardType={f.keyboardType || 'default'}
                                    />
                                </View>
                            ))}
                            <TouchableOpacity style={s.saveBtn} onPress={handleSave}>
                                <Ionicons name="checkmark" size={20} color="#fff" />
                                <Text style={s.saveBtnText}>Save</Text>
                            </TouchableOpacity>
                        </ScrollView>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const s = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.bg },
    topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20 },
    title: { fontSize: 22, fontWeight: '800', color: colors.text },
    addBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.primary, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20 },
    addText: { color: '#fff', fontWeight: '700', fontSize: 14 },
    card: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.bgCard, borderRadius: 16, padding: 16, marginBottom: 10, borderWidth: 1, borderColor: colors.border },
    primary: { fontSize: 15, fontWeight: '600', color: colors.text },
    secondary: { fontSize: 12, color: colors.textDim, marginTop: 2 },
    iconBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.04)', justifyContent: 'center', alignItems: 'center' },
    empty: { textAlign: 'center', color: colors.textDim, marginTop: 60 },
    overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
    modal: { backgroundColor: colors.bgCard, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, maxHeight: '80%' },
    modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
    modalTitle: { fontSize: 18, fontWeight: '700', color: colors.text },
    label: { fontSize: 13, fontWeight: '600', color: colors.textDim, marginBottom: 8 },
    input: { backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: 14, borderWidth: 1, borderColor: colors.border, color: colors.text, fontSize: 15, paddingVertical: 14, paddingHorizontal: 14 },
    saveBtn: { backgroundColor: colors.primary, borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 8 },
    saveBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
