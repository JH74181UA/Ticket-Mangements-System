import React, { useState, useEffect, useCallback } from 'react';
import {
    View, Text, FlatList, TouchableOpacity, StyleSheet,
    ActivityIndicator, RefreshControl, TextInput, Alert, Modal, ScrollView
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import api from '../api';
import { colors, statusColor } from '../theme';

const STATUSES = ['All', 'Pending', 'Assigned', 'In-Progress', 'On-Hold', 'Completed'];

export default function ComplaintsListScreen({ navigation }) {
    const [complaints, setComplaints] = useState([]);
    const [filtered, setFiltered] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [search, setSearch] = useState('');
    const [statusFilter, setStatusFilter] = useState('All');
    const [user, setUser] = useState({ role: 'User' });
    const [selected, setSelected] = useState(null);
    const [modalVisible, setModalVisible] = useState(false);
    const [updatingStatus, setUpdatingStatus] = useState(false);

    const fetchData = async () => {
        try {
            const userStr = await AsyncStorage.getItem('user');
            const u = userStr ? JSON.parse(userStr) : user;
            setUser(u);
            const res = await api.get(u.role === 'SuperAdmin' ? '/complaints/all' : '/complaints/my-complaints');
            setComplaints(res.data);
            applyFilter(res.data, statusFilter, search);
        } catch (err) {
            console.warn('Fetch complaints error:', err.message);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const applyFilter = useCallback((data, status, q) => {
        let result = data;
        if (status !== 'All') result = result.filter(c => c.status === status);
        if (q.trim()) result = result.filter(c =>
            c.remarks?.toLowerCase().includes(q.toLowerCase()) ||
            c.complaintType?.toLowerCase().includes(q.toLowerCase()) ||
            c.blockName?.toLowerCase().includes(q.toLowerCase())
        );
        setFiltered(result);
    }, []);

    useFocusEffect(
        useCallback(() => {
            fetchData();
        }, [])
    );
    useEffect(() => { applyFilter(complaints, statusFilter, search); }, [statusFilter, search, complaints]);

    useEffect(() => {
        if (navigation?.setOptions) {
            navigation.setOptions({
                title: user.role === 'SuperAdmin' ? 'All Tickets' : 'My Tickets'
            });
        }
    }, [user.role, navigation]);

    const handleUpdateStatus = async (id, newStatus) => {
        setUpdatingStatus(true);
        try {
            const res = await api.put(`/complaints/${id}/status`, { status: newStatus });
            if (res.data) {
                setSelected(res.data);
            }
            await fetchData();
            setModalVisible(false);
        } catch (err) {
            console.error('Update status error:', err.response?.data || err.message);
            Alert.alert('Error', err.response?.data?.message || 'Failed to update status');
        } finally {
            setUpdatingStatus(false);
        }
    };

    const handleDelete = (id) => {
        Alert.alert('Delete Ticket', 'Are you sure you want to delete this ticket?', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Delete', style: 'destructive', onPress: async () => {
                    try {
                        await api.delete(`/complaints/${id}`);
                        await fetchData();
                    } catch { Alert.alert('Error', 'Failed to delete'); }
                }
            }
        ]);
    };

    const renderItem = ({ item }) => (
        <TouchableOpacity style={s.card} onPress={() => { setSelected(item); setModalVisible(true); }}>
            <View style={s.cardTop}>
                <View style={[s.typeTag, { backgroundColor: colors.primaryLight }]}>
                    <Text style={[s.typeText, { color: colors.primary }]}>{item.complaintType}</Text>
                </View>
                <View style={[s.badge, { backgroundColor: statusColor(item.status) + '20', borderColor: statusColor(item.status) + '40' }]}>
                    <Text style={[s.badgeText, { color: statusColor(item.status) }]}>{item.status}</Text>
                </View>
            </View>
            <Text style={s.cardRemarks} numberOfLines={2}>{item.remarks}</Text>
            <View style={s.cardMeta}>
                <Ionicons name="location-outline" size={12} color={colors.textDim} />
                <Text style={s.metaText}>{item.blockName} · Room {item.roomNumber}</Text>
                <Ionicons name="time-outline" size={12} color={colors.textDim} style={{ marginLeft: 10 }} />
                <Text style={s.metaText}>{new Date(item.createdAt).toLocaleDateString()}</Text>
            </View>
        </TouchableOpacity>
    );

    return (
        <View style={s.container}>
            {/* Search */}
            <View style={s.searchRow}>
                <Ionicons name="search-outline" size={18} color={colors.textDim} style={{ marginLeft: 14 }} />
                <TextInput
                    style={s.searchInput}
                    placeholder="Search tickets..."
                    placeholderTextColor={colors.textDim}
                    value={search}
                    onChangeText={setSearch}
                />
            </View>

            {/* Status Filter Chips */}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.filterRow} contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}>
                {STATUSES.map(st => (
                    <TouchableOpacity
                        key={st}
                        style={[s.chip, statusFilter === st && { backgroundColor: st === 'All' ? colors.primary : statusColor(st), borderColor: 'transparent' }]}
                        onPress={() => setStatusFilter(st)}
                    >
                        <Text style={[s.chipText, statusFilter === st && { color: '#fff' }]}>{st}</Text>
                    </TouchableOpacity>
                ))}
            </ScrollView>

            {loading ? (
                <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 60 }} />
            ) : (
                <FlatList
                    data={filtered}
                    keyExtractor={i => i._id}
                    renderItem={renderItem}
                    contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
                    refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor={colors.primary} />}
                    ListEmptyComponent={<Text style={s.empty}>No tickets found.</Text>}
                />
            )}

            {/* Detail Modal */}
            <Modal visible={modalVisible} animationType="slide" transparent>
                <View style={s.overlay}>
                    <View style={s.modal}>
                        <View style={s.modalHeader}>
                            <Text style={s.modalTitle}>Ticket Detail</Text>
                            <TouchableOpacity onPress={() => setModalVisible(false)}>
                                <Ionicons name="close" size={24} color={colors.text} />
                            </TouchableOpacity>
                        </View>
                        {selected && (
                            <ScrollView>
                                <Row label="Type" value={selected.complaintType} />
                                <Row label="Block" value={selected.blockName} />
                                <Row label="Room" value={selected.roomNumber} />
                                <Row label="Status">
                                    <Text style={{ color: statusColor(selected.status), fontWeight: '700' }}>{selected.status}</Text>
                                </Row>
                                <Row label="Remarks" value={selected.remarks} />
                                <Row label="Raised By" value={selected.raisedBy?.username || 'N/A'} />
                                <Row label="Date" value={new Date(selected.createdAt).toLocaleString()} />

                                {(user.role === 'SuperAdmin' ||
                                    ['Technician', 'Plumber', 'Electrician', 'Networking Staff', 'Software Developer'].includes(user.role) ||
                                    (selected.assignedTo && (selected.assignedTo._id === user.id || selected.assignedTo === user.id))) && (
                                    <>
                                        <Text style={[s.label, { marginTop: 16 }]}>Update Status</Text>
                                        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
                                            {['Pending', 'Assigned', 'In-Progress', 'On-Hold', 'Completed'].map(st => (
                                                <TouchableOpacity
                                                    key={st}
                                                    style={[s.chip, { marginRight: 8, backgroundColor: statusColor(st) + '20', borderColor: statusColor(st) + '40' }]}
                                                    onPress={() => handleUpdateStatus(selected._id, st)}
                                                    disabled={updatingStatus}
                                                >
                                                    <Text style={{ color: statusColor(st), fontSize: 12, fontWeight: '700' }}>{st}</Text>
                                                </TouchableOpacity>
                                            ))}
                                        </ScrollView>
                                    </>
                                )}

                                {user.role === 'SuperAdmin' && (
                                    <TouchableOpacity style={s.deleteBtn} onPress={() => { setModalVisible(false); handleDelete(selected._id); }}>
                                        <Ionicons name="trash-outline" size={16} color={colors.danger} />
                                        <Text style={{ color: colors.danger, fontWeight: '700' }}>Delete Ticket</Text>
                                    </TouchableOpacity>
                                )}
                            </ScrollView>
                        )}
                    </View>
                </View>
            </Modal>

            {/* FAB */}
            <TouchableOpacity style={s.fab} onPress={() => navigation.navigate('RaiseComplaint')}>
                <Ionicons name="add" size={28} color="#fff" />
            </TouchableOpacity>
        </View>
    );
}

const Row = ({ label, value, children }) => (
    <View style={{ marginBottom: 14 }}>
        <Text style={{ color: colors.textDim, fontSize: 12, fontWeight: '600', marginBottom: 4 }}>{label}</Text>
        {children || <Text style={{ color: colors.text, fontSize: 14 }}>{value}</Text>}
    </View>
);

const s = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.bg },
    searchRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.bgCard, marginHorizontal: 16, marginVertical: 8, borderRadius: 12, borderWidth: 1, borderColor: colors.border },
    searchInput: { flex: 1, color: colors.text, fontSize: 14, paddingVertical: 8, paddingHorizontal: 10 },
    filterRow: { flexGrow: 0, marginBottom: 8 },
    chip: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 16, backgroundColor: colors.bgCard, borderWidth: 1, borderColor: colors.border },
    chipText: { color: colors.textDim, fontSize: 12, fontWeight: '600' },
    card: { backgroundColor: colors.bgCard, borderRadius: 14, paddingVertical: 10, paddingHorizontal: 14, marginBottom: 8, borderWidth: 1, borderColor: colors.border },
    cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
    typeTag: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, alignSelf: 'flex-start' },
    typeText: { fontSize: 11, fontWeight: '700' },
    badge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10, borderWidth: 1, alignSelf: 'flex-start' },
    badgeText: { fontSize: 11, fontWeight: '700' },
    cardRemarks: { color: colors.text, fontSize: 14, lineHeight: 19, marginBottom: 6 },
    cardMeta: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
    metaText: { color: colors.textDim, fontSize: 11 },
    empty: { textAlign: 'center', color: colors.textDim, marginTop: 60, fontSize: 15 },
    overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
    modal: { backgroundColor: colors.bgCard, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, maxHeight: '80%' },
    modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
    modalTitle: { fontSize: 18, fontWeight: '700', color: colors.text },
    label: { fontSize: 13, fontWeight: '600', color: colors.textDim, marginBottom: 8 },
    deleteBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: 'rgba(239,68,68,0.1)', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: 'rgba(239,68,68,0.2)' },
    fab: { position: 'absolute', bottom: 24, right: 24, width: 56, height: 56, borderRadius: 28, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center', elevation: 6 },
});
