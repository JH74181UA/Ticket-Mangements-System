import React from 'react';
import MasterDataScreen from '../MasterDataScreen';

export const DepartmentScreen = () => (
    <MasterDataScreen
        endpoint="/master/departments"
        title="Departments"
        fields={[
            { key: 'name', label: 'Department Name', placeholder: 'e.g. Computer Science' },
            { key: 'shortName', label: 'Short Code', placeholder: 'e.g. CSE (optional)' },
        ]}
    />
);

export const ProgrammeScreen = () => (
    <MasterDataScreen
        endpoint="/master/programmes"
        title="Programmes"
        fields={[
            { key: 'name', label: 'Programme Name', placeholder: 'e.g. B.Tech CSE' },
            { key: 'shortName', label: 'Short Code', placeholder: 'e.g. BTECH (optional)' },
            { key: 'duration', label: 'Duration (years)', placeholder: '4', keyboardType: 'numeric' },
        ]}
    />
);

export const BlockScreen = () => (
    <MasterDataScreen
        endpoint="/master/blocks"
        title="Blocks"
        fields={[
            { key: 'name', label: 'Block Name', placeholder: 'e.g. Block A' },
            { key: 'description', label: 'Description', placeholder: 'Optional description' },
        ]}
    />
);

export const RoomScreen = () => (
    <MasterDataScreen
        endpoint="/master/rooms"
        title="Rooms"
        fields={[
            { key: 'roomNumber', label: 'Room Number', placeholder: 'e.g. 101' },
            { key: 'block', label: 'Block', placeholder: 'Block name' },
            { key: 'capacity', label: 'Capacity', placeholder: '30', keyboardType: 'numeric' },
        ]}
    />
);

export const RoleScreen = () => (
    <MasterDataScreen
        endpoint="/master/roles"
        title="Roles"
        fields={[{ key: 'name', label: 'Role Name', placeholder: 'e.g. Technician' }]}
    />
);

export const UserScreen = () => (
    <MasterDataScreen
        endpoint="/master/users"
        title="Users"
        fields={[
            { key: 'username', label: 'Username', placeholder: 'Full name' },
            { key: 'email', label: 'Email', placeholder: 'user@tms.com', keyboardType: 'email-address' },
            { key: 'phoneNumber', label: 'Phone', placeholder: '9999999999', keyboardType: 'phone-pad' },
            { key: 'password', label: 'Password', placeholder: 'Default: User@123' },
        ]}
    />
);
