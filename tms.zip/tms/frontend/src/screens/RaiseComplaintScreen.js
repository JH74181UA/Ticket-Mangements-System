import React, { useState, useCallback, useRef } from 'react';
import {
    View, Text, TextInput, TouchableOpacity, ScrollView,
    StyleSheet, Alert, ActivityIndicator, KeyboardAvoidingView, Platform
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import api from '../api';
import { colors } from '../theme';

const COMPLAINT_TYPES = [
    'PC Hardware', 'PC Software', 'Application Issues',
    'Network', 'Electronics', 'Plumbing', 'Other'
];

const INITIAL_FORM = { blockName: '', roomNumber: '', complaintType: '', remarks: '', attachment: '' };

export default function RaiseComplaintScreen({ navigation }) {
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const [form, setForm] = useState(INITIAL_FORM);
    const timerRef = useRef(null);

    const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

    const navigateToTickets = useCallback(() => {
        if (timerRef.current) clearTimeout(timerRef.current);
        setSuccess(false);
        if (navigation.canGoBack()) {
            navigation.goBack();
        } else {
            navigation.navigate('MainTabs', { screen: 'Tickets' });
        }
    }, [navigation]);

    // Reset success state whenever navigating to the create page
    useFocusEffect(
        useCallback(() => {
            setSuccess(false);
            setLoading(false);
            return () => {
                if (timerRef.current) clearTimeout(timerRef.current);
            };
        }, [])
    );

    const handleSubmit = async () => {
        if (!form.blockName || !form.roomNumber || !form.complaintType || !form.remarks) {
            Alert.alert('Missing Fields', 'Please fill all required fields.');
            return;
        }
        setLoading(true);
        try {
            await api.post('/complaints/raise', form);
            setSuccess(true);
            setForm(INITIAL_FORM);
            timerRef.current = setTimeout(() => {
                navigateToTickets();
            }, 1500);
        } catch (err) {
            Alert.alert('Error', err.response?.data?.message || 'Failed to raise complaint');
            setLoading(false);
        }
    };

    if (success) {
        return (
            <View style={[s.container, { justifyContent: 'center', alignItems: 'center', padding: 20 }]}>
                <View style={s.successCard}>
                    <Ionicons name="checkmark-circle" size={68} color={colors.success} />
                    <Text style={s.successTitle}>Ticket Raised!</Text>
                    <Text style={s.successSub}>Your complaint has been submitted successfully.</Text>
                    
                    <View style={{ flexDirection: 'row', gap: 12, marginTop: 24, width: '100%' }}>
                        <TouchableOpacity
                            style={[s.btnOutline, { flex: 1 }]}
                            onPress={() => {
                                if (timerRef.current) clearTimeout(timerRef.current);
                                setSuccess(false);
                            }}
                        >
                            <Text style={s.btnOutlineText}>Raise Another</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[s.btnSolid, { flex: 1 }]}
                            onPress={navigateToTickets}
                        >
                            <Text style={s.btnSolidText}>All Tickets</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        );
    }

    return (
        <KeyboardAvoidingView style={s.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
                <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
                    <Ionicons name="arrow-back" size={20} color={colors.text} />
                    <Text style={s.backText}>Back</Text>
                </TouchableOpacity>

                <Text style={s.title}>Raise a Complaint</Text>
                <Text style={s.subtitle}>Provide details to help us resolve quickly.</Text>

                <Field label="Block Name" icon="location-outline" placeholder="e.g. Block A" value={form.blockName} onChangeText={v => set('blockName', v)} />
                <Field label="Room Number" icon="keypad-outline" placeholder="e.g. 101" value={form.roomNumber} onChangeText={v => set('roomNumber', v)} />

                {/* Category Picker */}
                <Text style={s.label}><Ionicons name="alert-circle-outline" size={14} /> Category *</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 18 }}>
                    {COMPLAINT_TYPES.map(type => (
                        <TouchableOpacity
                            key={type}
                            style={[s.chip, form.complaintType === type && s.chipActive]}
                            onPress={() => set('complaintType', type)}
                        >
                            <Text style={[s.chipText, form.complaintType === type && { color: '#fff' }]}>{type}</Text>
                        </TouchableOpacity>
                    ))}
                </ScrollView>

                {/* Remarks */}
                <Text style={s.label}><Ionicons name="document-text-outline" size={14} /> Detailed Remarks *</Text>
                <TextInput
                    style={[s.input, s.textarea]}
                    placeholder="Describe the problem in detail..."
                    placeholderTextColor={colors.textDim}
                    value={form.remarks}
                    onChangeText={v => set('remarks', v)}
                    multiline
                    numberOfLines={5}
                    textAlignVertical="top"
                />

                <Field label="Attachment URL (Optional)" icon="attach-outline" placeholder="Image/File link" value={form.attachment} onChangeText={v => set('attachment', v)} />

                <TouchableOpacity style={s.submitBtn} onPress={handleSubmit} disabled={loading}>
                    {loading
                        ? <ActivityIndicator color="#fff" />
                        : <><Ionicons name="send" size={20} color="#fff" /><Text style={s.submitText}>Submit Complaint Ticket</Text></>
                    }
                </TouchableOpacity>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const Field = ({ label, icon, placeholder, value, onChangeText }) => (
    <View style={{ marginBottom: 18 }}>
        <Text style={s.label}><Ionicons name={icon} size={14} /> {label}</Text>
        <View style={s.inputRow}>
            <Ionicons name={icon} size={16} color={colors.textDim} style={{ marginLeft: 12 }} />
            <TextInput style={s.input} placeholder={placeholder} placeholderTextColor={colors.textDim} value={value} onChangeText={onChangeText} />
        </View>
    </View>
);

const s = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.bg },
    content: { padding: 20, paddingBottom: 40 },
    backBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 20 },
    backText: { color: colors.text, fontSize: 15 },
    title: { fontSize: 26, fontWeight: '800', color: colors.text, marginBottom: 6 },
    subtitle: { fontSize: 14, color: colors.textDim, marginBottom: 28 },
    label: { fontSize: 13, fontWeight: '600', color: colors.textDim, marginBottom: 8 },
    inputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.bgCard, borderRadius: 14, borderWidth: 1, borderColor: colors.border },
    input: { flex: 1, color: colors.text, fontSize: 15, paddingVertical: 14, paddingHorizontal: 10 },
    textarea: { backgroundColor: colors.bgCard, borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 14, minHeight: 120, marginBottom: 18 },
    chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: colors.bgCard, borderWidth: 1, borderColor: colors.border, marginRight: 8 },
    chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
    chipText: { color: colors.textDim, fontSize: 13, fontWeight: '600' },
    submitBtn: { backgroundColor: colors.primary, borderRadius: 14, padding: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, marginTop: 8 },
    submitText: { color: '#fff', fontSize: 16, fontWeight: '700' },
    successCard: { backgroundColor: colors.bgCard, borderRadius: 24, padding: 32, alignItems: 'center', borderWidth: 1, borderColor: colors.border, width: '100%', maxWidth: 360 },
    successTitle: { fontSize: 24, fontWeight: '800', color: colors.text, marginTop: 16 },
    successSub: { color: colors.textDim, marginTop: 6, textAlign: 'center' },
    btnOutline: { borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingVertical: 12, alignItems: 'center' },
    btnOutlineText: { color: colors.text, fontWeight: '600', fontSize: 14 },
    btnSolid: { backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 12, alignItems: 'center' },
    btnSolidText: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
