import React, { useState } from 'react';
import {
    View, Text, TextInput, TouchableOpacity,
    StyleSheet, Alert, KeyboardAvoidingView,
    Platform, ScrollView, ActivityIndicator
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import api from '../api';
import { colors } from '../theme';

export default function LoginScreen({ navigation }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [showPass, setShowPass] = useState(false);
    const [error, setError] = useState('');

    const handleLogin = async () => {
        if (!email || !password) {
            setError('Please enter email and password');
            return;
        }
        setLoading(true);
        setError('');
        try {
            const { data } = await api.post('/auth/login', { email, password });
            await AsyncStorage.setItem('token', data.token);
            await AsyncStorage.setItem('user', JSON.stringify(data.user));
            navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
        } catch (err) {
            const msg = err.response?.data?.message || err.message || 'Login failed';
            console.warn('Login failed:', msg);
            setError(msg);
        } finally {
            setLoading(false);
        }
    };

    return (
        <KeyboardAvoidingView
            style={s.container}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
            <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
                {/* Logo */}
                <View style={s.logoWrap}>
                    <View style={s.logoIcon}>
                        <Ionicons name="shield-checkmark" size={40} color={colors.primary} />
                    </View>
                    <Text style={s.logoTitle}>TMS Pro</Text>
                    <Text style={s.logoSub}>Ticket Management Solutions</Text>
                </View>

                {/* Card */}
                <View style={s.card}>
                    <Text style={s.cardTitle}>Sign In</Text>

                    {/* Email */}
                    <View style={s.fieldWrap}>
                        <Text style={s.label}>Email Address</Text>
                        <View style={s.inputRow}>
                            <Ionicons name="mail-outline" size={18} color={colors.textDim} style={s.inputIcon} />
                            <TextInput
                                style={s.input}
                                placeholder="admin@tms.com"
                                placeholderTextColor={colors.textDim}
                                value={email}
                                onChangeText={setEmail}
                                keyboardType="email-address"
                                autoCapitalize="none"
                            />
                        </View>
                    </View>

                    {/* Password */}
                    <View style={s.fieldWrap}>
                        <Text style={s.label}>Password</Text>
                        <View style={s.inputRow}>
                            <Ionicons name="lock-closed-outline" size={18} color={colors.textDim} style={s.inputIcon} />
                            <TextInput
                                style={[s.input, { flex: 1 }]}
                                placeholder="••••••••"
                                placeholderTextColor={colors.textDim}
                                value={password}
                                onChangeText={setPassword}
                                secureTextEntry={!showPass}
                            />
                            <TouchableOpacity onPress={() => setShowPass(!showPass)} style={s.eyeBtn}>
                                <Ionicons name={showPass ? 'eye-off-outline' : 'eye-outline'} size={18} color={colors.textDim} />
                            </TouchableOpacity>
                        </View>
                    </View>

                    {/* Error */}
                    {!!error && (
                        <View style={s.errorBox}>
                            <Ionicons name="alert-circle-outline" size={16} color={colors.danger} />
                            <Text style={s.errorText}>{error}</Text>
                        </View>
                    )}

                    {/* Submit */}
                    <TouchableOpacity style={s.btn} onPress={handleLogin} disabled={loading}>
                        {loading
                            ? <ActivityIndicator color="#fff" />
                            : <><Ionicons name="log-in-outline" size={20} color="#fff" /><Text style={s.btnText}>Sign In to Portal</Text></>
                        }
                    </TouchableOpacity>
                </View>

                <Text style={s.footer}>Empowering your workflow with precision.</Text>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const s = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.bg },
    scroll: { flexGrow: 1, justifyContent: 'center', padding: 24 },
    logoWrap: { alignItems: 'center', marginBottom: 36 },
    logoIcon: { backgroundColor: colors.primaryLight, padding: 16, borderRadius: 20, marginBottom: 12 },
    logoTitle: { fontSize: 32, fontWeight: '800', color: colors.primary, letterSpacing: 1 },
    logoSub: { fontSize: 14, color: colors.textDim, marginTop: 4 },
    card: { backgroundColor: colors.bgCard, borderRadius: 24, padding: 28, borderWidth: 1, borderColor: colors.border },
    cardTitle: { fontSize: 22, fontWeight: '700', color: colors.text, marginBottom: 24 },
    fieldWrap: { marginBottom: 18 },
    label: { fontSize: 13, color: colors.textDim, fontWeight: '600', marginBottom: 8 },
    inputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: 14, borderWidth: 1, borderColor: colors.border },
    inputIcon: { paddingLeft: 14 },
    input: { flex: 1, color: colors.text, fontSize: 15, paddingVertical: 14, paddingHorizontal: 10 },
    eyeBtn: { paddingRight: 14 },
    errorBox: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(239,68,68,0.1)', borderRadius: 12, padding: 12, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(239,68,68,0.2)' },
    errorText: { color: colors.danger, fontSize: 13 },
    btn: { backgroundColor: colors.primary, borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 8 },
    btnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
    footer: { textAlign: 'center', color: colors.textDim, fontSize: 13, marginTop: 24 },
});
