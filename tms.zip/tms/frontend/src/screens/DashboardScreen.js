import React, { useState, useCallback } from 'react';
import {
    View, Text, ScrollView, TouchableOpacity,
    StyleSheet, ActivityIndicator, RefreshControl,
    Modal, Alert, Platform
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import api from '../api';
import { colors, statusColor } from '../theme';

export default function DashboardScreen({ navigation }) {
    const [user, setUser] = useState({ username: '', role: 'User' });
    const [stats, setStats] = useState({ Total: 0, Pending: 0, Assigned: 0, Completed: 0, 'In-Progress': 0 });
    const [recent, setRecent] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [profileVisible, setProfileVisible] = useState(false);

    const fetchData = async (silent = false) => {
        if (!silent) setLoading(true);
        try {
            const userStr = await AsyncStorage.getItem('user');
            const u = userStr ? JSON.parse(userStr) : user;
            setUser(u);
            const [statsRes, complaintsRes] = await Promise.all([
                api.get('/complaints/stats').catch(e => { console.warn('Stats fetch error:', e.message); return { data: {} }; }),
                api.get(u.role === 'SuperAdmin' ? '/complaints/all' : '/complaints/my-complaints').catch(e => { console.warn('Complaints fetch error:', e.message); return { data: [] }; }),
            ]);
            if (statsRes?.data) setStats(prev => ({ ...prev, ...statsRes.data }));
            if (Array.isArray(complaintsRes?.data)) setRecent(complaintsRes.data.slice(0, 5));
        } catch (err) {
            console.warn('Dashboard fetchData error:', err.response?.data?.message || err.message);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            // Auto-fetch tickets and stats whenever user returns to dashboard
            fetchData(recent.length > 0);
        }, [recent.length])
    );

    const handleLogout = async () => {
        setProfileVisible(false);
        await AsyncStorage.clear();
        navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
    };

    const confirmLogout = () => {
        if (Platform.OS === 'web') {
            if (window.confirm('Are you sure you want to sign out?')) {
                handleLogout();
            }
        } else {
            Alert.alert(
                'Sign Out',
                'Are you sure you want to sign out?',
                [
                    { text: 'Cancel', style: 'cancel' },
                    { text: 'Sign Out', style: 'destructive', onPress: handleLogout }
                ]
            );
        }
    };

    const statItems = [
        { label: 'Total', value: stats.Total || 0, icon: 'ticket-outline', color: colors.primary },
        { label: 'Pending', value: stats.Pending || 0, icon: 'time-outline', color: colors.warning },
        { label: 'In Progress', value: (stats.Assigned || 0) + (stats['In-Progress'] || 0), icon: 'settings-outline', color: colors.info },
        { label: 'Resolved', value: stats.Completed || 0, icon: 'checkmark-circle-outline', color: colors.success },
    ];

    if (loading) {
        return (
            <View style={[s.container, { justifyContent: 'center', alignItems: 'center' }]}>
                <ActivityIndicator size="large" color={colors.primary} />
            </View>
        );
    }

    return (
        <ScrollView
            style={s.container}
            contentContainerStyle={s.content}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor={colors.primary} />}
        >
            {/* Header */}
            <View style={s.header}>
                <View>
                    <Text style={s.greeting}>Overview</Text>
                    <Text style={s.subGreeting}>Welcome back, <Text style={{ color: colors.primary }}>{user.username}</Text></Text>
                </View>
                <TouchableOpacity
                    style={s.avatar}
                    onPress={() => setProfileVisible(true)}
                    activeOpacity={0.8}
                    accessibilityLabel="User Profile"
                >
                    <Text style={s.avatarText}>{user.username?.[0]?.toUpperCase() ?? 'A'}</Text>
                </TouchableOpacity>
            </View>

            {/* Profile Modal */}
            <Modal
                visible={profileVisible}
                transparent={true}
                animationType="fade"
                onRequestClose={() => setProfileVisible(false)}
            >
                <TouchableOpacity
                    style={s.modalOverlay}
                    activeOpacity={1}
                    onPress={() => setProfileVisible(false)}
                >
                    <TouchableOpacity
                        activeOpacity={1}
                        style={s.profileCard}
                        onPress={(e) => e.stopPropagation()}
                    >
                        <View style={s.profileHeader}>
                            <Text style={s.modalTitle}>User Profile</Text>
                            <TouchableOpacity onPress={() => setProfileVisible(false)} style={s.closeBtn}>
                                <Ionicons name="close" size={20} color={colors.textDim} />
                            </TouchableOpacity>
                        </View>

                        <View style={s.profileAvatarWrap}>
                            <View style={s.largeAvatar}>
                                <Text style={s.largeAvatarText}>{user.username?.[0]?.toUpperCase() ?? 'A'}</Text>
                            </View>
                            <Text style={s.profileName}>{user.username}</Text>
                            <View style={s.rolePill}>
                                <Ionicons name="shield-checkmark" size={14} color={colors.primary} />
                                <Text style={s.roleText}>{user.role || 'User'}</Text>
                            </View>
                        </View>

                        <View style={s.infoSection}>
                            <View style={s.infoRow}>
                                <Ionicons name="mail-outline" size={18} color={colors.textDim} />
                                <View style={{ flex: 1 }}>
                                    <Text style={s.infoLabel}>Email</Text>
                                    <Text style={s.infoValue}>{user.email || 'Not provided'}</Text>
                                </View>
                            </View>
                            <View style={s.infoRow}>
                                <Ionicons name="person-outline" size={18} color={colors.textDim} />
                                <View style={{ flex: 1 }}>
                                    <Text style={s.infoLabel}>Username</Text>
                                    <Text style={s.infoValue}>{user.username}</Text>
                                </View>
                            </View>
                        </View>

                        {user.role === 'SuperAdmin' && (
                            <View style={s.masterDataLinks}>
                                <Text style={s.masterDataTitle}>Management Tools</Text>
                                <View style={s.managementGrid}>
                                    {[
                                        { label: 'Users', icon: 'people', screen: 'Users' },
                                        { label: 'Roles', icon: 'key', screen: 'Roles' },
                                        { label: 'Depts', icon: 'business', screen: 'Departments' },
                                        { label: 'Blocks', icon: 'cube', screen: 'Blocks' },
                                        { label: 'Rooms', icon: 'grid', screen: 'Rooms' },
                                        { label: 'Programmes', icon: 'school', screen: 'Programmes' },
                                    ].map((m) => (
                                        <TouchableOpacity
                                            key={m.screen}
                                            style={s.masterBtn}
                                            onPress={() => {
                                                setProfileVisible(false);
                                                navigation.navigate(m.screen);
                                            }}
                                        >
                                            <Ionicons name={m.icon} size={16} color={colors.primary} />
                                            <Text style={s.masterBtnText}>{m.label}</Text>
                                        </TouchableOpacity>
                                    ))}
                                </View>
                            </View>
                        )}

                        <TouchableOpacity style={s.modalLogoutBtn} onPress={confirmLogout}>
                            <Ionicons name="log-out-outline" size={18} color={colors.danger} />
                            <Text style={s.modalLogoutText}>Sign Out</Text>
                        </TouchableOpacity>
                    </TouchableOpacity>
                </TouchableOpacity>
            </Modal>

            {/* Stats Grid */}
            <View style={s.grid}>
                {statItems.map((item) => (
                    <TouchableOpacity
                        key={item.label}
                        style={[s.statCard, { borderColor: item.color + '30' }]}
                        activeOpacity={0.7}
                        onPress={() => navigation.navigate('ComplaintsList')}
                    >
                        <View style={[s.statIcon, { backgroundColor: item.color + '20' }]}>
                            <Ionicons name={item.icon} size={22} color={item.color} />
                        </View>
                        <Text style={s.statValue}>{item.value}</Text>
                        <Text style={s.statLabel}>{item.label}</Text>
                    </TouchableOpacity>
                ))}
            </View>

            {/* Quick Actions */}
            <View style={s.section}>
                <Text style={s.sectionTitle}>Quick Actions</Text>
                <View style={s.actionsRow}>
                    <TouchableOpacity style={s.actionBtn} onPress={() => navigation.navigate('RaiseComplaint')}>
                        <Ionicons name="add-circle" size={26} color={colors.primary} />
                        <Text style={s.actionLabel}>Raise Ticket</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={s.actionBtn} onPress={() => navigation.navigate('ComplaintsList')}>
                        <Ionicons name="list" size={26} color={colors.accent} />
                        <Text style={s.actionLabel}>{user.role === 'SuperAdmin' ? 'All Tickets' : 'My Tickets'}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={s.actionBtn} onPress={() => navigation.navigate('Reports')}>
                        <Ionicons name="bar-chart" size={26} color={colors.success} />
                        <Text style={s.actionLabel}>Reports</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={s.actionBtn} onPress={() => navigation.navigate('Notifications')}>
                        <Ionicons name="notifications" size={26} color={colors.warning} />
                        <Text style={s.actionLabel}>Alerts</Text>
                    </TouchableOpacity>
                </View>
            </View>

            {/* Recent Complaints */}
            <View style={s.section}>
                <View style={s.sectionHeader}>
                    <Text style={s.sectionTitle}>{user.role === 'SuperAdmin' ? 'Recent Tickets' : 'My Recent Tickets'}</Text>
                    <TouchableOpacity onPress={() => navigation.navigate('ComplaintsList')}>
                        <Text style={{ color: colors.primary, fontSize: 13 }}>View All</Text>
                    </TouchableOpacity>
                </View>
                {recent.length === 0 ? (
                    <Text style={s.empty}>No recent activity.</Text>
                ) : (
                    recent.map((c) => (
                        <TouchableOpacity
                            key={c._id}
                            style={s.ticketRow}
                            activeOpacity={0.7}
                            onPress={() => navigation.navigate('ComplaintsList')}
                        >
                            <View style={[s.ticketIcon, { backgroundColor: colors.primaryLight }]}>
                                <Ionicons name="ticket-outline" size={20} color={colors.primary} />
                            </View>
                            <View style={{ flex: 1 }}>
                                <Text style={s.ticketTitle} numberOfLines={1}>
                                    {c.remarks?.substring(0, 50)}{c.remarks?.length > 50 ? '...' : ''}
                                </Text>
                                <Text style={s.ticketMeta}>{c.complaintType} • {new Date(c.createdAt).toLocaleDateString()}</Text>
                            </View>
                            <View style={[s.badge, { backgroundColor: statusColor(c.status) + '20', borderColor: statusColor(c.status) + '40' }]}>
                                <Text style={[s.badgeText, { color: statusColor(c.status) }]}>{c.status}</Text>
                            </View>
                        </TouchableOpacity>
                    ))
                )}
            </View>

            {/* Logout */}
            <TouchableOpacity style={s.logoutBtn} onPress={confirmLogout}>
                <Ionicons name="log-out-outline" size={18} color={colors.danger} />
                <Text style={s.logoutText}>Sign Out</Text>
            </TouchableOpacity>
        </ScrollView>
    );
}

const s = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.bg },
    content: { padding: 20, paddingBottom: 40 },
    header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 },
    greeting: { fontSize: 26, fontWeight: '700', color: colors.text },
    subGreeting: { fontSize: 14, color: colors.textDim, marginTop: 2 },
    avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' },
    avatarText: { color: '#fff', fontWeight: '700', fontSize: 18 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 28 },
    statCard: { flex: 1, minWidth: '45%', backgroundColor: colors.bgCard, borderRadius: 18, padding: 18, borderWidth: 1 },
    statIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
    statValue: { fontSize: 28, fontWeight: '800', color: colors.text },
    statLabel: { fontSize: 12, color: colors.textDim, marginTop: 4, fontWeight: '600' },
    section: { marginBottom: 28 },
    sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
    sectionTitle: { fontSize: 17, fontWeight: '700', color: colors.text, marginBottom: 14 },
    actionsRow: { flexDirection: 'row', gap: 12 },
    actionBtn: { flex: 1, backgroundColor: colors.bgCard, borderRadius: 16, padding: 16, alignItems: 'center', gap: 8, borderWidth: 1, borderColor: colors.border },
    actionLabel: { fontSize: 11, color: colors.textDim, fontWeight: '600', textAlign: 'center' },
    ticketRow: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: colors.bgCard, borderRadius: 16, padding: 16, marginBottom: 10, borderWidth: 1, borderColor: colors.border },
    ticketIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
    ticketTitle: { fontSize: 14, fontWeight: '600', color: colors.text },
    ticketMeta: { fontSize: 12, color: colors.textDim, marginTop: 2 },
    badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, borderWidth: 1 },
    badgeText: { fontSize: 11, fontWeight: '700' },
    empty: { textAlign: 'center', color: colors.textDim, padding: 20 },
    logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: 'rgba(239,68,68,0.1)', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: 'rgba(239,68,68,0.2)', marginTop: 8 },
    logoutText: { color: colors.danger, fontWeight: '700', fontSize: 15 },

    /* Profile Modal Styles */
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', alignItems: 'center', padding: 20 },
    profileCard: { width: '100%', maxWidth: 380, backgroundColor: colors.bgCard, borderRadius: 24, padding: 24, borderWidth: 1, borderColor: colors.border },
    profileHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
    modalTitle: { fontSize: 18, fontWeight: '700', color: colors.text },
    closeBtn: { padding: 4 },
    profileAvatarWrap: { alignItems: 'center', marginBottom: 20 },
    largeAvatar: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
    largeAvatarText: { color: '#fff', fontWeight: '800', fontSize: 32 },
    profileName: { fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 6 },
    rolePill: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(108,99,255,0.15)', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(108,99,255,0.3)' },
    roleText: { color: colors.primary, fontSize: 12, fontWeight: '700' },
    infoSection: { backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: 16, padding: 14, gap: 12, marginBottom: 18, borderWidth: 1, borderColor: colors.border },
    infoRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    infoLabel: { fontSize: 11, color: colors.textDim, textTransform: 'uppercase', letterSpacing: 0.5 },
    infoValue: { fontSize: 14, color: colors.text, fontWeight: '600', marginTop: 1 },
    masterDataLinks: { marginBottom: 18 },
    masterDataTitle: { fontSize: 12, fontWeight: '700', color: colors.textDim, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 },
    managementGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    masterBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1, borderColor: colors.border, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 10 },
    masterBtnText: { color: colors.text, fontSize: 12, fontWeight: '600' },
    modalLogoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: 'rgba(239,68,68,0.12)', borderRadius: 14, padding: 12, borderWidth: 1, borderColor: 'rgba(239,68,68,0.25)', marginTop: 4 },
    modalLogoutText: { color: colors.danger, fontWeight: '700', fontSize: 14 },
});
