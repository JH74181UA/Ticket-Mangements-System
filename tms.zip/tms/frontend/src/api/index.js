import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';
import { Platform } from 'react-native';

const getBaseUrl = () => {
    // 1. Expo Go on physical device: hostUri contains "ip:port" of Metro server
    const hostUri = Constants.expoConfig?.hostUri || Constants.manifest2?.extra?.expoGo?.debuggerHost;
    if (hostUri) {
        const ip = hostUri.split(':')[0];
        return `http://${ip}:5000/api`;
    }

    // 2. Web browser
    if (Platform.OS === 'web') {
        return 'http://localhost:5000/api';
    }

    // 3. Fallback for physical device / emulator
    return 'http://192.168.1.179:5000/api';
};

const BASE_URL = getBaseUrl();
console.log('[API] Configured BASE_URL:', BASE_URL);

const api = axios.create({
    baseURL: BASE_URL,
    timeout: 10000,
});

api.interceptors.request.use(async (config) => {
    const token = await AsyncStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

api.interceptors.response.use(
    (response) => response,
    (error) => {
        const status = error.response?.status;
        const method = error.config?.method?.toUpperCase() || 'REQ';
        const url = error.config?.url || '';
        const message = error.response?.data?.message || error.message;

        console.warn(`[Axios ${status || 'Network'}] ${method} ${url} -> ${message}`);
        return Promise.reject(error);
    }
);

export default api;

