const { Department, Programme, Block, Room } = require('../models/Master');
const Role = require('../models/Role');

// Generic helper function to handle CRUD
const createMaster = (Model) => async (req, res) => {
    try {
        const itemData = { ...req.body };
        // Auto-fill shortName from name if model has it and not provided
        if (itemData.name && !itemData.shortName) {
            itemData.shortName = itemData.name.substring(0, 10).toUpperCase();
        }
        const item = new Model(itemData);
        await item.save();
        res.status(201).json(item);
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({ message: 'An item with this name already exists' });
        }
        res.status(400).json({ message: error.message });
    }
};

const getAllMaster = (Model, populateFields = []) => async (req, res) => {
    try {
        let query = Model.find();
        populateFields.forEach(field => {
            query = query.populate(field);
        });
        const items = await query.sort({ createdAt: -1 });
        res.json(items);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const updateMaster = (Model) => async (req, res) => {
    try {
        const item = await Model.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!item) {
            return res.status(404).json({ message: 'Item not found' });
        }
        res.json(item);
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({ message: 'An item with this name already exists' });
        }
        res.status(400).json({ message: error.message });
    }
};

const deleteMaster = (Model) => async (req, res) => {
    try {
        const item = await Model.findByIdAndDelete(req.params.id);
        if (!item) {
            return res.status(404).json({ message: 'Item not found' });
        }
        res.json({ message: 'Deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Exports
module.exports = {
    // Departments
    getDepartments: getAllMaster(Department),
    createDepartment: createMaster(Department),
    updateDepartment: updateMaster(Department),
    deleteDepartment: deleteMaster(Department),

    // Programmes
    getProgrammes: getAllMaster(Programme),
    createProgramme: createMaster(Programme),
    updateProgramme: updateMaster(Programme),
    deleteProgramme: deleteMaster(Programme),

    // Blocks
    getBlocks: getAllMaster(Block),
    createBlock: createMaster(Block),
    updateBlock: updateMaster(Block),
    deleteBlock: deleteMaster(Block),

    // Rooms
    getRooms: getAllMaster(Room),
    createRoom: createMaster(Room),
    updateRoom: updateMaster(Room),
    deleteRoom: deleteMaster(Room),

    // Roles
    getRoles: getAllMaster(Role),
    createRole: createMaster(Role),
    updateRole: updateMaster(Role),
    deleteRole: deleteMaster(Role),
};
