const User = require('../models/User');
const Role = require('../models/Role');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.registerSuperAdmin = async (req, res) => {
    try {
        const { username, phoneNumber, email, password, secretKey } = req.body;

        // Basic secret key check for initialization
        if (secretKey !== process.env.SUPERADMIN_SECRET) {
            return res.status(403).json({ message: 'Unauthorized' });
        }

        const role = await Role.findOne({ name: 'SuperAdmin' });
        if (!role) {
            return res.status(400).json({ message: 'SuperAdmin role not found. Please seed roles first.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({
            username,
            phoneNumber,
            email,
            password: hashedPassword,
            role: role._id
        });

        await newUser.save();
        res.status(201).json({ message: 'SuperAdmin created successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email }).populate('role');
        if (!user) return res.status(400).json({ message: 'User not found' });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

        const token = jwt.sign(
            { id: user._id, role: user.role.name },
            process.env.JWT_SECRET,
            { expiresIn: '1d' }
        );

        res.json({
            token,
            user: {
                id: user._id,
                username: user.username,
                role: user.role.name,
                email: user.email
            }
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
exports.createUser = async (req, res) => {
    try {
        const { username, email, password, phoneNumber, role, department, programme } = req.body;

        if (!email || !username) {
            return res.status(400).json({ message: 'Username and email are required' });
        }

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists with this email' });
        }

        // Determine role (fallback to 'User' or first available role if not provided)
        let userRoleId = role;
        if (!userRoleId) {
            const defaultRole = (await Role.findOne({ name: 'User' })) || (await Role.findOne());
            if (defaultRole) {
                userRoleId = defaultRole._id;
            }
        }

        const rawPassword = password && password.trim() ? password : 'User@123';
        const hashedPassword = await bcrypt.hash(rawPassword, 10);
        const newUser = new User({
            username,
            email,
            password: hashedPassword,
            phoneNumber: phoneNumber || 'N/A',
            role: userRoleId,
            department: department || undefined,
            programme: programme || undefined
        });

        await newUser.save();
        const populatedUser = await User.findById(newUser._id).select('-password').populate('role').populate('department').populate('programme');
        res.status(201).json(populatedUser);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getUsers = async (req, res) => {
    try {
        const users = await User.find().select('-password').populate('role').populate('department').populate('programme');
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.updateUser = async (req, res) => {
    try {
        const { password, ...updateData } = req.body;
        if (password && password.trim()) {
            updateData.password = await bcrypt.hash(password, 10);
        } else {
            delete updateData.password;
        }

        if (updateData.role && typeof updateData.role === 'object') {
            updateData.role = updateData.role._id;
        }
        if (updateData.department && typeof updateData.department === 'object') {
            updateData.department = updateData.department._id;
        }
        if (updateData.programme && typeof updateData.programme === 'object') {
            updateData.programme = updateData.programme._id;
        }

        const user = await User.findByIdAndUpdate(req.params.id, updateData, { new: true })
            .select('-password')
            .populate('role')
            .populate('department')
            .populate('programme');
        res.json(user);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

exports.deleteUser = async (req, res) => {
    try {
        await User.findByIdAndDelete(req.params.id);
        res.json({ message: 'User deleted' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
