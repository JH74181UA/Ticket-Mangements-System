const mongoose = require('mongoose');
const Complaint = require('../models/Complaint');
const User = require('../models/User');
const { createNotification } = require('./notificationController');

exports.raiseComplaint = async (req, res) => {
    try {
        const { blockName, roomNumber, complaintType, remarks, attachment } = req.body;

        const userId = req.user.id;
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const newComplaint = new Complaint({
            blockName,
            roomNumber,
            complaintType,
            remarks,
            attachment,
            raisedBy: userId,
            department: user.department
        });

        await newComplaint.save();

        // Notify SuperAdmins
        const Role = require('../models/Role');
        const adminRole = await Role.findOne({ name: 'SuperAdmin' });
        if (adminRole) {
            const admins = await User.find({ role: adminRole._id });
            for (const admin of admins) {
                await createNotification(
                    admin._id,
                    userId,
                    `New ${complaintType} ticket raised: ${blockName}/${roomNumber}`,
                    'System',
                    newComplaint._id,
                    '/complaints-list'
                );
            }
        }

        res.status(201).json({ message: 'Complaint raised successfully', complaint: newComplaint });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getUserComplaints = async (req, res) => {
    try {
        const userId = req.user.id;
        const complaints = await Complaint.find({
            $or: [
                { raisedBy: userId },
                { assignedTo: userId }
            ]
        })
            .populate('raisedBy', 'username')
            .populate('assignedTo', 'username')
            .sort({ createdAt: -1 });

        res.json(complaints);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getAllComplaints = async (req, res) => {
    try {
        // SuperAdmin can view all
        const complaints = await Complaint.find()
            .populate('raisedBy', 'username')
            .populate('assignedTo', 'username')
            .sort({ createdAt: -1 });
        res.json(complaints);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getReportData = async (req, res) => {
    try {
        const { startDate, endDate, status, complaintType } = req.query;
        let query = {};

        if (startDate && endDate) {
            const end = new Date(endDate);
            end.setHours(23, 59, 59, 999);
            query.createdAt = {
                $gte: new Date(startDate),
                $lte: end
            };
        }

        if (status && status !== 'All') query.status = status;
        if (complaintType && complaintType !== 'All') query.complaintType = complaintType;

        const complaints = await Complaint.find(query)
            .populate('raisedBy', 'username')
            .populate('assignedTo', 'username')
            .sort({ createdAt: -1 });

        res.json(complaints);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getComplaintStats = async (req, res) => {
    try {
        const userId = req.user.id;
        const role = req.user.role;

        let matchQuery = {};
        if (role !== 'SuperAdmin') {
            const userObjId = new mongoose.Types.ObjectId(userId);
            matchQuery = {
                $or: [
                    { raisedBy: userObjId },
                    { assignedTo: userObjId }
                ]
            };
        }

        const stats = await Complaint.aggregate([
            { $match: matchQuery },
            { $group: { _id: '$status', count: { $sum: 1 } } }
        ]);

        const formattedStats = {
            Total: 0,
            Pending: 0,
            Assigned: 0,
            'In-Progress': 0,
            'On-Hold': 0,
            Completed: 0
        };

        stats.forEach(s => {
            if (formattedStats.hasOwnProperty(s._id)) {
                formattedStats[s._id] = s.count;
            }
            formattedStats.Total += s.count;
        });

        res.json(formattedStats);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.assignComplaint = async (req, res) => {
    try {
        const { assignedTo } = req.body;
        const complaint = await Complaint.findByIdAndUpdate(
            req.params.id,
            { assignedTo, status: 'Assigned' },
            { new: true, runValidators: true }
        );

        if (!complaint) {
            return res.status(404).json({ message: 'Complaint not found' });
        }

        if (assignedTo) {
            await createNotification(
                assignedTo,
                req.user.id,
                `New ticket assigned to you: ${complaint.complaintType} at ${complaint.blockName}/${complaint.roomNumber}`,
                'Assignment',
                complaint._id,
                '/complaints-list'
            );
        }

        res.json(complaint);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.updateComplaintStatus = async (req, res) => {
    try {
        const { status } = req.body;
        if (!status) {
            return res.status(400).json({ message: 'Status is required' });
        }

        const validStatuses = ['Pending', 'Assigned', 'In-Progress', 'On-Hold', 'Completed'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ message: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
        }

        const complaint = await Complaint.findByIdAndUpdate(
            req.params.id,
            { status },
            { new: true, runValidators: true }
        );

        if (!complaint) {
            return res.status(404).json({ message: 'Complaint not found' });
        }

        if (complaint.raisedBy) {
            await createNotification(
                complaint.raisedBy,
                req.user.id,
                `Your ticket status has been updated to: ${status}`,
                'StatusUpdate',
                complaint._id,
                '/complaints-list'
            );
        }

        res.json(complaint);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.updateComplaint = async (req, res) => {
    try {
        const { blockName, roomNumber, complaintType, remarks } = req.body;
        const complaint = await Complaint.findByIdAndUpdate(
            req.params.id,
            { blockName, roomNumber, complaintType, remarks },
            { new: true }
        );
        res.json(complaint);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

exports.deleteComplaint = async (req, res) => {
    try {
        await Complaint.findByIdAndDelete(req.params.id);
        // Also delete associated notifications
        const Notification = require('../models/Notification');
        await Notification.deleteMany({ relatedId: req.params.id });
        res.json({ message: 'Complaint deleted' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
