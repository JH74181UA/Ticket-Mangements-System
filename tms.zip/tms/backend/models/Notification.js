const mongoose = require('mongoose');

const NotificationSchema = new mongoose.Schema({
    recipient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    message: { type: String, required: true },
    type: {
        type: String,
        enum: ['Assignment', 'StatusUpdate', 'Message', 'System'],
        default: 'System'
    },
    relatedId: { type: mongoose.Schema.Types.ObjectId }, // e.g., Complaint ID
    read: { type: Boolean, default: false },
    link: { type: String } // Frontend link to navigate to
}, { timestamps: true });

module.exports = mongoose.model('Notification', NotificationSchema);
