const mongoose = require('mongoose');

const ComplaintSchema = new mongoose.Schema({
    blockName: { type: String, required: true },
    roomNumber: { type: String, required: true },
    complaintType: {
        type: String,
        required: true,
        enum: ['PC Hardware', 'PC Software', 'Application Issues', 'Network', 'Electronics', 'Plumbing', 'Other']
    },
    remarks: { type: String, required: true },
    attachment: { type: String }, // URL or file path
    status: {
        type: String,
        enum: ['Pending', 'Assigned', 'In-Progress', 'On-Hold', 'Completed'],
        default: 'Pending'
    },
    raisedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' }
}, { timestamps: true });

module.exports = mongoose.model('Complaint', ComplaintSchema);
