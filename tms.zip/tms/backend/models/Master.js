const mongoose = require('mongoose');

// Department Schema
const DepartmentSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true, trim: true },
    shortName: { type: String, trim: true }
}, { timestamps: true });

const Department = mongoose.model('Department', DepartmentSchema);

// Programme Schema
const ProgrammeSchema = new mongoose.Schema({
    name: { type: String, required: true, trim: true },
    shortName: { type: String, trim: true },
    duration: { type: String, trim: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' }
}, { timestamps: true });

const Programme = mongoose.model('Programme', ProgrammeSchema);

// Block Schema
const BlockSchema = new mongoose.Schema({
    name: { type: String, required: true, trim: true },
    description: { type: String, trim: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    programme: { type: mongoose.Schema.Types.ObjectId, ref: 'Programme' }
}, { timestamps: true });

const Block = mongoose.model('Block', BlockSchema);

// Room Number Schema
const RoomSchema = new mongoose.Schema({
    roomNumber: { type: String, required: true, trim: true },
    block: { type: String, trim: true },
    capacity: { type: String, trim: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    programme: { type: mongoose.Schema.Types.ObjectId, ref: 'Programme' }
}, { timestamps: true });

const Room = mongoose.model('Room', RoomSchema);

module.exports = { Department, Programme, Block, Room };
