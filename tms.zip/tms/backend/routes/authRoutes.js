const express = require('express');
const router = express.Router();
const { login, registerSuperAdmin } = require('../controllers/authController');

router.post('/login', login);
router.post('/register-superadmin', registerSuperAdmin);

// User Management (Admin only)
const { verifyToken, authorizeRoles } = require('../middleware/authMiddleware');
const { getUsers, updateUser, deleteUser, createUser } = require('../controllers/authController');

router.get('/users', verifyToken, authorizeRoles('SuperAdmin'), getUsers);
router.post('/users', verifyToken, authorizeRoles('SuperAdmin'), createUser);
router.put('/users/:id', verifyToken, authorizeRoles('SuperAdmin'), updateUser);
router.delete('/users/:id', verifyToken, authorizeRoles('SuperAdmin'), deleteUser);

module.exports = router;
