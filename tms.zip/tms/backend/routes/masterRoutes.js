const express = require('express');
const router = express.Router();
const masterController = require('../controllers/masterController');
const { verifyToken, authorizeRoles } = require('../middleware/authMiddleware');

// All master routes protected by SuperAdmin
router.use(verifyToken, authorizeRoles('SuperAdmin'));

// Departments
router.get('/departments', masterController.getDepartments);
router.post('/departments', masterController.createDepartment);
router.put('/departments/:id', masterController.updateDepartment);
router.delete('/departments/:id', masterController.deleteDepartment);

// Programmes
router.get('/programmes', masterController.getProgrammes);
router.post('/programmes', masterController.createProgramme);
router.put('/programmes/:id', masterController.updateProgramme);
router.delete('/programmes/:id', masterController.deleteProgramme);

// Blocks
router.get('/blocks', masterController.getBlocks);
router.post('/blocks', masterController.createBlock);
router.put('/blocks/:id', masterController.updateBlock);
router.delete('/blocks/:id', masterController.deleteBlock);

// Rooms
router.get('/rooms', masterController.getRooms);
router.post('/rooms', masterController.createRoom);
router.put('/rooms/:id', masterController.updateRoom);
router.delete('/rooms/:id', masterController.deleteRoom);

// Roles
router.get('/roles', masterController.getRoles);
router.post('/roles', masterController.createRole);
router.put('/roles/:id', masterController.updateRole);
router.delete('/roles/:id', masterController.deleteRole);

// Users
const { getUsers, createUser, updateUser, deleteUser } = require('../controllers/authController');
router.get('/users', getUsers);
router.post('/users', createUser);
router.put('/users/:id', updateUser);
router.delete('/users/:id', deleteUser);

module.exports = router;
