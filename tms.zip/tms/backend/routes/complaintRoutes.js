const express = require('express');
const router = express.Router();
const {
    raiseComplaint,
    getUserComplaints,
    getAllComplaints,
    getComplaintStats,
    assignComplaint,
    updateComplaintStatus,
    getReportData,
    updateComplaint,
    deleteComplaint
} = require('../controllers/complaintController');
const { verifyToken, authorizeRoles } = require('../middleware/authMiddleware');

router.post('/raise', verifyToken, raiseComplaint);
router.get('/my-complaints', verifyToken, getUserComplaints);
router.get('/all', verifyToken, authorizeRoles('SuperAdmin'), getAllComplaints);
router.get('/stats', verifyToken, getComplaintStats);
router.get('/reports', verifyToken, authorizeRoles('SuperAdmin'), getReportData);

// Process Flow
router.put('/:id/status', verifyToken, updateComplaintStatus);
router.put('/status/:id', verifyToken, updateComplaintStatus);
router.put('/:id/assign', verifyToken, authorizeRoles('SuperAdmin'), assignComplaint);
router.put('/assign/:id', verifyToken, authorizeRoles('SuperAdmin'), assignComplaint);
router.put('/:id', verifyToken, authorizeRoles('SuperAdmin'), updateComplaint);
router.delete('/:id', verifyToken, authorizeRoles('SuperAdmin'), deleteComplaint);

module.exports = router;
